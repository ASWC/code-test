﻿using ClassAverageCalculator.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassAverageCalculator.Controllers
{
    /*      
     * Collects valid class/student data from csv files
     * Does not process same class twice.
     */

    public static class GradeCollector
    {
        private static List<string> parsedFiles = new List<string>();
        private static Dictionary<string, ClassModel> _classes = new Dictionary<string, ClassModel>();
        public static bool requiresUpdate { get; set; }

        public static async Task addGradeFile(string file)
        {
            if(parsedFiles.Contains(file))
            {
                // we already parsed that file
                return;
            }
            try
            {
                parsedFiles.Append(file);
                string classname = Path.GetFileNameWithoutExtension(file);
                string[] lines = File.ReadAllLines(file).Skip(1).ToArray();
                foreach(string line in lines)
                {
                    string[] data = line.Split(',');
                    await Task.Run(() => addStudent(data[0], data[1], classname));
                }
            }
            catch
            {
                // eventually log error
            }            
        }

        private static void addStudent(string name, string grade, string className)
        {
            try
            {
                double studentgrade = Convert.ToDouble(grade);
                StudentModel student = new StudentModel(name, studentgrade, className);
                if(!_classes.ContainsKey(className))
                {
                    ClassModel _class = new ClassModel();
                    _class.name = className;
                    _classes.Add(className, _class);
                }
                _classes[className].add(student);
                requiresUpdate = true;
            }
            catch
            {
                // eventually log error
            }
        }

        public static Dictionary<string, ClassModel> classes
        {
            get
            {
                return _classes;
            }
        }

        
    }
}
