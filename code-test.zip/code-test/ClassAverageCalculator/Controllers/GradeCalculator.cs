﻿using ClassAverageCalculator.Models;
using System;
using System.Linq;
using System.Text;

namespace ClassAverageCalculator.Controllers
{
    public static class GradeCalculator
    {
        public static string getResult()
        {
            // using LinQ to get most important results
            // calculations occur in the getter 'average' of the ClassModel
            StringBuilder stringResult = new StringBuilder();
            try
            {
                var bestclass = GradeCollector.classes.Select(item => item.Value).OrderByDescending(item => item.average).Take(1).ElementAt(0);
                stringResult.Append("Top Class: " + bestclass.name + ". Average grade: " + Convert.ToString(Math.Round(bestclass.average)));
            }
            catch
            {
                // log error
            }
            stringResult.AppendLine();
            stringResult.AppendLine();
            var sortedclasses = GradeCollector.classes.Select(item => item.Value).OrderByDescending(item => item.average);
            int order = 1;
            foreach(ClassModel _class in sortedclasses)
            {
                stringResult.Append(order + " " + _class.name + " Average Grade: " + Convert.ToString(Math.Round(_class.average)));
                stringResult.AppendLine();
                order++;
            }
            stringResult.AppendLine();
            stringResult.AppendLine();
            foreach (ClassModel _class in sortedclasses)
            {
                stringResult.Append(_class.name + " Details:");
                stringResult.AppendLine();
                stringResult.Append("Total Number of Student: " + _class.totalStudents);
                stringResult.AppendLine();
                stringResult.Append("Total Number of Student Included in Average: " + _class.totalStudentsWithGrade);
                if(_class.totalStudents != _class.totalStudentsWithGrade)
                {
                    stringResult.AppendLine();
                    stringResult.Append("Students Excluded from Average: " + _class.getExcludedStudentNames());
                }               
                stringResult.AppendLine();
                stringResult.AppendLine();
            }
            stringResult.AppendLine();
            stringResult.AppendLine();
            return stringResult.ToString();
        }
    }
}
