﻿
namespace ClassAverageCalculator.Models
{
    public class StudentModel
    {
        public string name { get; set; }
        public double grade { get; set; }
        public string className { get; set; }

        /*      
         * Hold student values
         */

        public StudentModel(string name, double grade, string className)
        {
            this.name = name;
            this.grade = grade;
            this.className = className;
        }
    }
}
