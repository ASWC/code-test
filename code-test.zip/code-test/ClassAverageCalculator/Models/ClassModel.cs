﻿using System;
using System.Collections.Generic;

namespace ClassAverageCalculator.Models
{
    /*      
     * Hold class data and self calculate average on demand.
     * Does not process same student twice.
     */

    public class ClassModel
    {
        protected Dictionary<string, StudentModel> students;
        protected int _totalStudents;
        public string name { get; set; }

        public ClassModel()
        {
            students = new Dictionary<string, StudentModel>();
        }

        public void add(StudentModel student)
        {
            if(!students.ContainsKey(student.name))
            {
                students.Add(student.name, student);
                _totalStudents++;
            }
        }
        
        public int totalStudentsWithGrade
        {
            get
            {
                int studentcount = 0;
                foreach (KeyValuePair<string, StudentModel> item in students)
                {
                    if (item.Value.grade > 0)
                    {
                        studentcount++;
                    }
                }
                return studentcount;
            }
        }

        public string getExcludedStudentNames()
        {
            string result = "";
            foreach (KeyValuePair<string, StudentModel> item in students)
            {
                if (item.Value.grade == 0)
                {
                    result += item.Value.name + " ";
                }
            }
            return result;
        }

        public int totalStudents
        {
            get
            {
                return students.Count;
            }
        }

        public double average
        {
            get
            {
                double studentcount = 0;
                double gradetotal = 0;
                foreach(KeyValuePair<string, StudentModel> item in students)
                {
                    if(item.Value.grade > 0)
                    {
                        studentcount++;
                        gradetotal += item.Value.grade;
                    }
                }
                return gradetotal / studentcount;
            }
        }
    }

    
}
