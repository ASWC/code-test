﻿
using ClassAverageCalculator.Controllers;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;

namespace ClassAverageCalculator
{
    /// <summary>
    /// I did choose a WPF for simplicity but this could have been done as well with MVC or Blazor
    /// within a server environement.
    /// I do use an updated version of my CSVGenerator class (https://github.com/ASWC/csvgenerator) for convenience.
    /// </summary>

    public partial class MainWindow : Window
    {
        protected OpenFileDialog fileSelector;

        public MainWindow()
        {
            InitializeComponent();
            this.fileSelector = new OpenFileDialog();
            this.fileSelector.Filter = "Data (*.csv;)|*.CSV;";
            this.fileSelector.Multiselect = true;
            this.fileSelector.Title = "Select Grade Compatible .csv file(s).";
        }

        private async void handleSelectMultipleFiles(object sender, RoutedEventArgs e)
        {
            DialogResult result = (DialogResult)this.fileSelector.ShowDialog();
            if (result == System.Windows.Forms.DialogResult.OK)
            {
                foreach (string file in fileSelector.FileNames)
                {
                    // the GradeCollector will decide whether the passed file is valid and whether the system needs to recalculate.
                    await GradeCollector.addGradeFile(file);
                }
                if (GradeCollector.requiresUpdate)
                {
                    _outputBox.Text = GradeCalculator.getResult();
                }
            }
        }

        private void handleResultExport(object sender, RoutedEventArgs e)
        {
            if (_outputBox.Text.Length > 0) // simple check but does the job
            {
                var folderbrowser = new FolderBrowserDialog();
                DialogResult result = folderbrowser.ShowDialog();
                if (result == System.Windows.Forms.DialogResult.OK)
                {
                    string folderName = folderbrowser.SelectedPath;
                    string fileName = "ExportedClassesAverage.txt";
                    string pathString = System.IO.Path.Combine(folderName, fileName);
                    File.WriteAllText(pathString, _outputBox.Text);// just write everything
                }
            }
        }
    }
}
